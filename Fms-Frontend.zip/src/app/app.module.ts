import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { MainComponent } from './main/main.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { FormsModule } from '@angular/forms';
import { AdminComponent } from './admin/admin.component';
import { BookingComponent } from './flight-booking/booking.component';
import { FlightAdminComponent } from './flight-admin/flight-admin.component';
import { AddflightComponent } from './addflight/addflight.component';
import { SearchflightComponent } from './searchflight/searchflight.component';
import { ScheduleadminComponent } from './scheduleadmin/scheduleadmin.component';
import { AddscheduleComponent } from './addschedule/addschedule.component';
import { SearchscheduleComponent } from './searchschedule/searchschedule.component';
import { FlightService } from './flight.service';
import { UpdateflightComponent } from './updateflight/updateflight.component';
import { UpdatescheduleComponent } from './updateschedule/updateschedule.component';
import { UpdateScheduleComponent } from './update-schedule/update-schedule.component';
import { PassengerComponent } from './passenger/passenger.component';
import { BookingdetailsComponent } from './bookingdetails/bookingdetails.component';
import { ViewbookingsComponent } from './viewbookings/viewbookings.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { BackgroundComponent } from './background/background.component';
import { LogoutComponent } from './logout/logout.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    MainComponent,
    LoginComponent,
    UserComponent,
    AdminComponent,
    BookingComponent,
    FlightAdminComponent,
    AddflightComponent,
    SearchflightComponent,
    ScheduleadminComponent,
    AddscheduleComponent,
    SearchscheduleComponent,
    UpdateflightComponent,
    UpdatescheduleComponent,
    UpdateScheduleComponent,
    PassengerComponent,
    BookingdetailsComponent,
    ViewbookingsComponent,
    BackgroundComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    FontAwesomeModule
  ],
  providers: [
    FlightService,
    DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
