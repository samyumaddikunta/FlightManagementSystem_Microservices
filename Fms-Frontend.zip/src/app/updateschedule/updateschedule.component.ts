import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateschedule',
  templateUrl: './updateschedule.component.html',
  styleUrls: ['./updateschedule.component.css']
})
export class UpdatescheduleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
